<template>
  <div>
    我是组织结构大组件
  </div>
</template>
<script>
export default {
  
}
</script>

<style lang="less">
  
</style>