<template>
  <div class="container">
    您来到了没有草原的荒野~~~~~~
    <a href="#/">点击回到首页</a>
  </div>
</template>
<script>
export default {
  
}
</script>

<style lang="less" scoped>
  .container {
    background: yellow;
    height: 100%;
  }
</style>