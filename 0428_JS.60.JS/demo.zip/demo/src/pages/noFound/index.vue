<template>
  <div>您当钱访问的页面不存在~~~ <a href="javascript:;">返回首页</a></div>
</template>

<script>
export default {
  
};
</script>

<style lang="less" scoped>
</style>