export const CHECK_IS_LOGIN = 'CHECK_IS_LOGIN';
export const QUERY_POWER = 'QUERY_POWER';

/* CUSTOM */
export const CUSTOM_QUERY_LIST = 'CUSTOM_QUERY_LIST';