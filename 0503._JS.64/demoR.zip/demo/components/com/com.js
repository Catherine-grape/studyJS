// components/com/com.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    msg: {
      type: String,
      default: '默认值'
    },
    
  },

  /**
   * 组件的初始数据
   */
  data: {

  },

  /**
   * 组件的方法列表
   */
  methods: {
    fn(e) {
      console.log(1111);
      this.triggerEvent('event',{num:100})
    },
  }
})
