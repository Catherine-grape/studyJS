// pages/home/home.js
const app =  getApp(); // 和获取当前最大的app实例
console.log(app);
Page({

  /**
   * 页面的初始数据
   */
  data: {
    msg:'Hello World',
    num:899
  },
  fn(e){
    console.log(111,e);
    // 点击hello跳转到a页面
    app.globalData.ss = 800;
    wx.navigateTo({ url: '/pages/a/a?type=1' });
    // wx.redirectTo({ url: '/pages/ss/ss' });
    // wx.reLaunch({ url: '/pages/ss/ss' });
  },
  changeMsg(){
    this.setData({
      msg:12345678
    });
  },
  fn1(){
    console.log('fn1');
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // 页面加载的时候会执行
    console.log('home-load');
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    console.log('home-show');
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    console.log('home-hide');
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    console.log('home-unLoad');
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})