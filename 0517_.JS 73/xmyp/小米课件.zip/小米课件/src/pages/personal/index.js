import React,{Component} from 'react';

class Personal extends Component {
  constructor(props) {
    super(props);
    this.state = {  };
  }
  render() {
    return (
        <div>这是个人组件</div>
    );
  }
}

export default Personal;