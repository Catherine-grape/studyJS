import React,{Component} from 'react';

class Cart extends Component {
  constructor(props) {
    super(props);
    this.state = {  };
  }
  render() {
    return (
        <div>这是购物车组件</div>
    );
  }
}

export default Cart;