// 同门一管理接口的地方
import home from './home';

export default {
  home
}



