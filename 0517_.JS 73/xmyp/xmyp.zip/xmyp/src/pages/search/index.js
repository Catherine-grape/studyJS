import React,{Component} from 'react';

class Search extends Component {
  constructor(props) {
    super(props);
    this.state = {  };
  }
  render() {
    return (
        <div>这是搜索页</div>
    );
  }
}

export default Search;