import React,{Component} from 'react';

class Classfl extends Component {
  constructor(props) {
    super(props);
    this.state = {  };
  }
  render() {
    return (
        <div>这是分类组件</div>
    );
  }
}

export default Classfl;