import React,{Component} from 'react';

class Taste extends Component {
  constructor(props) {
    super(props);
    this.state = {  };
  }
  render() {
    return (
        <div>这是品味组件</div>
    );
  }
}

export default Taste;