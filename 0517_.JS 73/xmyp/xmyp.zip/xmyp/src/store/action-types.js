export const INIT = 'INIT'; // 初始化init接口
export const HOT = 'HOT'; // 首页中的热门