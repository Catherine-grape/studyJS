<template>
  <div id="app">
    1111111
  </div>
</template>

<script>

export default {

};
</script>
<style lang="less">
html,
body {
  margin: 0;
  padding: 0;
  height: 100%;
  background: #f4f4f4;
}

#app {
  margin: 0 auto;
  max-width: 750px;
  min-height: 100%;
  background: #f4f4f4;
}
</style>