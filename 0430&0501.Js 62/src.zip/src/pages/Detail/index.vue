<template>
    <div>
      我是详情组件
    </div>
</template>

<script>
export default {
    props: {

    },
    data() {
        return {

        };
    },
};
</script>

<style scoped lang="less">

</style>
