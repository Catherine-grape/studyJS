<template>
    <div>
      我是通知
    </div>
</template>

<script>
export default {
    props: {

    },
    data() {
        return {

        };
    },
};
</script>

<style scoped lang="less">

</style>
