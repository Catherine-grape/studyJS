<template>
    <div>
      我是我的
    </div>
</template>

<script>
export default {
    props: {

    },
    data() {
        return {

        };
    },
};
</script>

<style scoped lang="less">

</style>
