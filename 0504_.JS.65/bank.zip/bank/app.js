// app.js
App({

}); // 相当于newVue
