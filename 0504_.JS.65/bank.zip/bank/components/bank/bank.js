
Component({
  properties: {
    data:{
      type:Array,
      default:[]
    }
  },

 
  data: {
    isHeight:true
  },

  
  methods: {
    fn(){
      let isHeight = !this.data.isHeight
      this.setData({
        isHeight
      })
    }
  }
})
