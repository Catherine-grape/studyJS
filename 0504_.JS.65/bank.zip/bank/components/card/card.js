// components/card/card.js
Component({

  properties: {
    data:{
      type:Array,
      default:[]
    }
  },
  data: {

  },
  methods: {
    jump(e){
      let cardCode = e.currentTarget.dataset.code;

      wx.navigateTo({
        url:`/pages/detail/detail?code=${cardCode}`
      });
    }
  }
})
