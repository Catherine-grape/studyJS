// components/title/title.js
Component({

  properties: {
    title:{
      type:String,
      default:'标题'
    },
    url:{
      type:String,
      default:''
    }
  },
  data: {

  },
  methods: {
    jump(){
      let url = this.properties.url
      wx.reLaunch({ url});
    }
  }
})
