let data = require('../../mock/data');
Page({

  data: {
    item:{}
  },
  onLoad: function (options) {
    let { cardList } = data
    let item = cardList.find((item) => {
      return item.cardCode == options.code
    });
    this.setData({item});
    console.log(item);
  },
  fn() {
    wx.showModal({
      title: '提示',
      content: '您确定要办理此卡吗',
      success(res) {
        if (res.confirm) {
          console.log('用户点击确定')
          wx.showToast({
            title: '办理成功', //提示的内容,
            icon: 'success', //图标,
            duration: 2000, //延迟时间,
            // mask: true, //显示透明蒙层，防止触摸穿透,
            // success: res => {}
          });
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })
  }
})