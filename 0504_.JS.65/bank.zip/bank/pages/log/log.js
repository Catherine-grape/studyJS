
Page({
    jump(){
     wx.switchTab({ url: '/pages/home/home' });
    }
})