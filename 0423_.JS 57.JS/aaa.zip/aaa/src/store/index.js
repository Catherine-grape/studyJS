import Vue from 'vue';
import Vuex from 'vuex';
import logger from 'vuex/dist/logger';

//  如果在模块化构建系统中，请确保在开头调用了 Vue.use(Vuex)
Vue.use(Vuex);

export default new Vuex.Store({
  state:{
    title:'给特朗普投票',
    supNum:0, // 支持人数
    popNum:0 // 反对人数
  },
  getters:{
    supRate(state){
      let sum = state.supNum + state.popNum;
      let res = state.supNum/sum *100;
      if(sum == 0){
        return 0
      }
      return res;
    }
  },
  mutations:{
    addSup(state){
      state.supNum++
    },
    addPop(state){
      state.popNum++
    }
  },
  actions:{
    addSup({commit},payload){
      commit('addSup',payload);
    },
    addPop({commit},payload){
      commit('addPop',payload);
    }
  },
  // logger可以在当前页面的控制台打印改变状态的日志
  plugins:[logger()]
})