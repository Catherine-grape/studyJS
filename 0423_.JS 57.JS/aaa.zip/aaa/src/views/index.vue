<template>
  <div>
    我是刚才新建的组件
  </div>
</template>

<script>
export default {
  
}
</script>

<style lang="less">
  
</style>