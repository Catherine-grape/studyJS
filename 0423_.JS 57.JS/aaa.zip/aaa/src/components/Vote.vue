
<style lang="less" scoped>
// 在style的行间写一个scoped，会让当前的样式只对当前的组件生效
  .vote {
    border:2px solid red;
    padding:10px;
    width: 500px;
    margin: 20px auto;
    text-align: center;
  }

</style>

<template>
  <div class="vote">
    <vote-title></vote-title>
    <vote-content></vote-content>
    <vote-footer></vote-footer>
  </div>
</template>

<script>
import VoteTitle from './VoteTitle';
import VoteContent from './VoteContent';
import VoteFooter from './VoteFooter';
export default {
    components:{
      VoteTitle,
      VoteContent,
      VoteFooter
    }
}
</script>

