
<style lang="less" scoped>
button {
  margin-right: 5px;
  background: chartreuse;
}
</style>

<template>
  <div>
    <button @click="addSup">支持</button>
    <button @click="addPop">反对</button>
  </div>
</template>

<script>
import {mapActions} from 'vuex';
export default {
  methods:{
    ...mapActions(['addSup','addPop']),
    // addSup(){
    //   this.$store.dispatch('addSup')
    // }

  }
};
</script>

