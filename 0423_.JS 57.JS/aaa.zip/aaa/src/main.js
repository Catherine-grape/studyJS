import Vue from 'vue'
import App from './App.vue';
import store from './store'; // 把当前的store仓库引进来

Vue.config.productionTip = false;

new Vue({ // 创建vue根实例
  store,
  render: h => h(App)
}).$mount('#app');


// new Vue({
//   el:'#app',
//   template:'<div>11111</div>'
// })